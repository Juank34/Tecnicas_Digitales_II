; Disassembled code
