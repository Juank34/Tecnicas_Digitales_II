/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define Led_Pin GPIO_PIN_13
#define Led_GPIO_Port GPIOC
#define LCD_RST_Pin GPIO_PIN_4
#define LCD_RST_GPIO_Port GPIOA
#define LCD_DC_Pin GPIO_PIN_6
#define LCD_DC_GPIO_Port GPIOA
#define LCD_CS_Pin GPIO_PIN_0
#define LCD_CS_GPIO_Port GPIOB
#define PulsadorIzquierdo_Pin GPIO_PIN_12
#define PulsadorIzquierdo_GPIO_Port GPIOB
#define PulsadorIzquierdo_EXTI_IRQn EXTI15_10_IRQn
#define PulsadorCentral_Pin GPIO_PIN_13
#define PulsadorCentral_GPIO_Port GPIOB
#define PulsadorCentral_EXTI_IRQn EXTI15_10_IRQn
#define PulsadorDerecho_Pin GPIO_PIN_14
#define PulsadorDerecho_GPIO_Port GPIOB
#define PulsadorDerecho_EXTI_IRQn EXTI15_10_IRQn
#define Eco1_Pin GPIO_PIN_4
#define Eco1_GPIO_Port GPIOB
#define Eco2_Pin GPIO_PIN_5
#define Eco2_GPIO_Port GPIOB
#define Trigger1_Pin GPIO_PIN_6
#define Trigger1_GPIO_Port GPIOB
#define Trigger2_Pin GPIO_PIN_7
#define Trigger2_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
